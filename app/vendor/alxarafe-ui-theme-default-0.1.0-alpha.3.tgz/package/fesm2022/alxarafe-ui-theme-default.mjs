import { ThemeArtifact, ThemeId, ThemeNavigationOutlet, ThemePanelOutlet, activateThemeLink } from "@alxarafe/ui-runtime";
import * as i0 from "@angular/core";
import { Component, Directive, computed, input, output } from "@angular/core";
var NavigationTree = class NavigationTree {
	items = input([], ...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	linkActivation = input(...ngDevMode ? [void 0, { debugName: "linkActivation" }] : /* istanbul ignore next */ []);
	activateLink = activateThemeLink;
	selected = output();
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: NavigationTree,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: NavigationTree,
		isStandalone: true,
		selector: "aur-default-navigation-tree",
		inputs: {
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			linkActivation: {
				classPropertyName: "linkActivation",
				publicName: "linkActivation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { selected: "selected" },
		ngImport: i0,
		template: `
    <ul>
      @for (item of items(); track item.id) {
        <li>
          @if (item.disabled) {
            <span aria-disabled="true">{{ item.label }}</span>
          } @else if (item.href) {
            <a [href]="item.href" [attr.target]="item.target ?? null" [attr.download]="item.download ?? null" (click)="activateLink(item, $event, linkActivation())" [attr.aria-current]="item.current ? 'page' : null">{{ item.label }}</a>
          } @else if (item.children?.length) {
            <span>{{ item.label }}</span>
          } @else {
            <button type="button" (click)="selected.emit({ itemId: item.id })">{{ item.label }}</button>
          }
          @if (!item.disabled && item.children?.length) {
            <aur-default-navigation-tree [items]="item.children!" [linkActivation]="linkActivation()" (selected)="selected.emit($event)" />
          }
        </li>
      }
    </ul>`,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NavigationTree,
			selector: "aur-default-navigation-tree",
			inputs: ["items", "linkActivation"],
			outputs: ["selected"]
		}]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: NavigationTree,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-navigation-tree",
			imports: [NavigationTree],
			template: `
    <ul>
      @for (item of items(); track item.id) {
        <li>
          @if (item.disabled) {
            <span aria-disabled="true">{{ item.label }}</span>
          } @else if (item.href) {
            <a [href]="item.href" [attr.target]="item.target ?? null" [attr.download]="item.download ?? null" (click)="activateLink(item, $event, linkActivation())" [attr.aria-current]="item.current ? 'page' : null">{{ item.label }}</a>
          } @else if (item.children?.length) {
            <span>{{ item.label }}</span>
          } @else {
            <button type="button" (click)="selected.emit({ itemId: item.id })">{{ item.label }}</button>
          }
          @if (!item.disabled && item.children?.length) {
            <aur-default-navigation-tree [items]="item.children!" [linkActivation]="linkActivation()" (selected)="selected.emit($event)" />
          }
        </li>
      }
    </ul>`
		}]
	}],
	propDecorators: {
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: false
			}]
		}],
		linkActivation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "linkActivation",
				required: false
			}]
		}],
		selected: [{
			type: i0.Output,
			args: ["selected"]
		}]
	}
});
var DefaultNavigation = class DefaultNavigation {
	items = input([], ...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	linkActivation = input(...ngDevMode ? [void 0, { debugName: "linkActivation" }] : /* istanbul ignore next */ []);
	selected = output();
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: DefaultNavigation,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: DefaultNavigation,
		isStandalone: true,
		selector: "aur-default-navigation",
		inputs: {
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			linkActivation: {
				classPropertyName: "linkActivation",
				publicName: "linkActivation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { selected: "selected" },
		ngImport: i0,
		template: "<nav aria-label=\"Application sections\"><aur-default-navigation-tree [items]=\"items()\" [linkActivation]=\"linkActivation()\" (selected)=\"selected.emit($event)\" /></nav>",
		isInline: true,
		dependencies: [{
			kind: "component",
			type: NavigationTree,
			selector: "aur-default-navigation-tree",
			inputs: ["items", "linkActivation"],
			outputs: ["selected"]
		}]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: DefaultNavigation,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-navigation",
			imports: [NavigationTree],
			template: "<nav aria-label=\"Application sections\"><aur-default-navigation-tree [items]=\"items()\" [linkActivation]=\"linkActivation()\" (selected)=\"selected.emit($event)\" /></nav>"
		}]
	}],
	propDecorators: {
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: false
			}]
		}],
		linkActivation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "linkActivation",
				required: false
			}]
		}],
		selected: [{
			type: i0.Output,
			args: ["selected"]
		}]
	}
});
var DefaultPanel = class DefaultPanel {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: DefaultPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: DefaultPanel,
		isStandalone: true,
		selector: "aur-default-panel",
		ngImport: i0,
		template: "<div class=\"aur-default-panel\"><ng-content /></div>",
		isInline: true
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: DefaultPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-panel",
			template: "<div class=\"aur-default-panel\"><ng-content /></div>"
		}]
	}]
});
var DefaultShell = class DefaultShell {
	navigation = input([], ...ngDevMode ? [{ debugName: "navigation" }] : /* istanbul ignore next */ []);
	linkActivation = input(...ngDevMode ? [void 0, { debugName: "linkActivation" }] : /* istanbul ignore next */ []);
	navigationSelected = output();
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: DefaultShell,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: DefaultShell,
		isStandalone: true,
		selector: "aur-default-shell",
		inputs: {
			navigation: {
				classPropertyName: "navigation",
				publicName: "navigation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			linkActivation: {
				classPropertyName: "linkActivation",
				publicName: "linkActivation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { navigationSelected: "navigationSelected" },
		ngImport: i0,
		template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<div class=\"aur-default-shell\">\n  <header class=\"aur-default-heading\">\n    <ng-content select='[aur-theme-region=\"topbar-start\"]' />\n    <ng-content select=\"[aur-shell-heading]\" />\n    <ng-content select='[aur-theme-region=\"topbar-actions\"]' />\n  </header>\n  <aside class=\"aur-default-navigation\">\n    <ng-content select='[aur-theme-region=\"navigation-before\"]' />\n    <aur-theme-navigation [items]=\"navigation()\" [linkActivation]=\"linkActivation()\" (selected)=\"navigationSelected.emit($event)\" />\n    <ng-content select='[aur-theme-region=\"navigation-after\"]' />\n  </aside>\n  <main class=\"aur-default-content\">\n    <ng-content select='[aur-theme-region=\"content-before\"]' />\n    <ng-content select='[aur-theme-region=\"contextual-actions\"]' />\n    <aur-theme-panel><ng-content select=\"[aur-shell-content]\" /></aur-theme-panel>\n    <ng-content select='[aur-theme-region=\"content-after\"]' />\n    <div class=\"aur-default-tools\"><ng-content select='[aur-theme-region=\"floating-actions\"]' /></div>\n    <div class=\"aur-default-unclaimed\"><ng-content /></div>\n  </main>\n  <footer class=\"aur-default-footer\">\n    <ng-content select=\"[aur-shell-footer]\" />\n    <ng-content select='[aur-theme-region=\"footer\"]' />\n  </footer>\n</div>\n",
		dependencies: [{
			kind: "component",
			type: ThemeNavigationOutlet,
			selector: "aur-theme-navigation",
			inputs: ["items", "linkActivation"],
			outputs: ["selected"]
		}, {
			kind: "component",
			type: ThemePanelOutlet,
			selector: "aur-theme-panel"
		}]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: DefaultShell,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-shell",
			imports: [ThemeNavigationOutlet, ThemePanelOutlet],
			template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<div class=\"aur-default-shell\">\n  <header class=\"aur-default-heading\">\n    <ng-content select='[aur-theme-region=\"topbar-start\"]' />\n    <ng-content select=\"[aur-shell-heading]\" />\n    <ng-content select='[aur-theme-region=\"topbar-actions\"]' />\n  </header>\n  <aside class=\"aur-default-navigation\">\n    <ng-content select='[aur-theme-region=\"navigation-before\"]' />\n    <aur-theme-navigation [items]=\"navigation()\" [linkActivation]=\"linkActivation()\" (selected)=\"navigationSelected.emit($event)\" />\n    <ng-content select='[aur-theme-region=\"navigation-after\"]' />\n  </aside>\n  <main class=\"aur-default-content\">\n    <ng-content select='[aur-theme-region=\"content-before\"]' />\n    <ng-content select='[aur-theme-region=\"contextual-actions\"]' />\n    <aur-theme-panel><ng-content select=\"[aur-shell-content]\" /></aur-theme-panel>\n    <ng-content select='[aur-theme-region=\"content-after\"]' />\n    <div class=\"aur-default-tools\"><ng-content select='[aur-theme-region=\"floating-actions\"]' /></div>\n    <div class=\"aur-default-unclaimed\"><ng-content /></div>\n  </main>\n  <footer class=\"aur-default-footer\">\n    <ng-content select=\"[aur-shell-footer]\" />\n    <ng-content select='[aur-theme-region=\"footer\"]' />\n  </footer>\n</div>\n"
		}]
	}],
	propDecorators: {
		navigation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "navigation",
				required: false
			}]
		}],
		linkActivation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "linkActivation",
				required: false
			}]
		}],
		navigationSelected: [{
			type: i0.Output,
			args: ["navigationSelected"]
		}]
	}
});
var FieldRendererBase = class FieldRendererBase {
	context = input.required(...ngDevMode ? [{ debugName: "context" }] : /* istanbul ignore next */ []);
	valueChange = output();
	text = computed(() => {
		const value = this.context().value;
		return typeof value === "string" ? value : "";
	}, ...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	update(value) {
		if (!this.context().disabled && !this.context().readOnly) this.valueChange.emit(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: FieldRendererBase,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: FieldRendererBase,
		isStandalone: true,
		inputs: { context: {
			classPropertyName: "context",
			publicName: "context",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		outputs: { valueChange: "valueChange" },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: FieldRendererBase,
	decorators: [{ type: Directive }],
	propDecorators: {
		context: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "context",
				required: true
			}]
		}],
		valueChange: [{
			type: i0.Output,
			args: ["valueChange"]
		}]
	}
});
var DefaultBooleanRenderer = class DefaultBooleanRenderer extends FieldRendererBase {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: DefaultBooleanRenderer,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: DefaultBooleanRenderer,
		isStandalone: true,
		selector: "aur-default-boolean",
		host: { classAttribute: "aur-default-field" },
		usesInheritance: true,
		ngImport: i0,
		template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<input\n  #control\n  type=\"checkbox\"\n  [id]=\"context().id\"\n  [checked]=\"context().value === true\"\n  [indeterminate]=\"context().value === null\"\n  [disabled]=\"context().disabled || context().readOnly\"\n  (change)=\"update(control.checked)\"\n/>\n"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: DefaultBooleanRenderer,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-boolean",
			host: { class: "aur-default-field" },
			template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<input\n  #control\n  type=\"checkbox\"\n  [id]=\"context().id\"\n  [checked]=\"context().value === true\"\n  [indeterminate]=\"context().value === null\"\n  [disabled]=\"context().disabled || context().readOnly\"\n  (change)=\"update(control.checked)\"\n/>\n"
		}]
	}]
});
var DefaultStringRenderer = class DefaultStringRenderer extends FieldRendererBase {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: DefaultStringRenderer,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: DefaultStringRenderer,
		isStandalone: true,
		selector: "aur-default-string",
		host: { classAttribute: "aur-default-field" },
		usesInheritance: true,
		ngImport: i0,
		template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<input\n  #control\n  type=\"text\"\n  [id]=\"context().id\"\n  [value]=\"text()\"\n  [disabled]=\"context().disabled ?? false\"\n  [readOnly]=\"context().readOnly ?? false\"\n  (input)=\"update(control.value)\"\n/>\n"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: DefaultStringRenderer,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-string",
			host: { class: "aur-default-field" },
			template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<input\n  #control\n  type=\"text\"\n  [id]=\"context().id\"\n  [value]=\"text()\"\n  [disabled]=\"context().disabled ?? false\"\n  [readOnly]=\"context().readOnly ?? false\"\n  (input)=\"update(control.value)\"\n/>\n"
		}]
	}]
});
var DefaultTextRenderer = class DefaultTextRenderer extends FieldRendererBase {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: DefaultTextRenderer,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: DefaultTextRenderer,
		isStandalone: true,
		selector: "aur-default-text",
		host: { classAttribute: "aur-default-field" },
		usesInheritance: true,
		ngImport: i0,
		template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<textarea\n  #control\n  [id]=\"context().id\"\n  [value]=\"text()\"\n  [disabled]=\"context().disabled ?? false\"\n  [readOnly]=\"context().readOnly ?? false\"\n  (input)=\"update(control.value)\"\n></textarea>\n"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: DefaultTextRenderer,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-text",
			host: { class: "aur-default-field" },
			template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<textarea\n  #control\n  [id]=\"context().id\"\n  [value]=\"text()\"\n  [disabled]=\"context().disabled ?? false\"\n  [readOnly]=\"context().readOnly ?? false\"\n  (input)=\"update(control.value)\"\n></textarea>\n"
		}]
	}]
});
var DefaultNumberRenderer = class DefaultNumberRenderer extends FieldRendererBase {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: DefaultNumberRenderer,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: DefaultNumberRenderer,
		isStandalone: true,
		selector: "aur-default-number",
		host: { classAttribute: "aur-default-field" },
		usesInheritance: true,
		ngImport: i0,
		template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<input\n  #control\n  type=\"text\"\n  inputmode=\"decimal\"\n  [id]=\"context().id\"\n  [value]=\"text()\"\n  [disabled]=\"context().disabled ?? false\"\n  [readOnly]=\"context().readOnly ?? false\"\n  (input)=\"update(control.value)\"\n/>\n"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: DefaultNumberRenderer,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-number",
			host: { class: "aur-default-field" },
			template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<input\n  #control\n  type=\"text\"\n  inputmode=\"decimal\"\n  [id]=\"context().id\"\n  [value]=\"text()\"\n  [disabled]=\"context().disabled ?? false\"\n  [readOnly]=\"context().readOnly ?? false\"\n  (input)=\"update(control.value)\"\n/>\n"
		}]
	}]
});
var DefaultDateRenderer = class DefaultDateRenderer extends FieldRendererBase {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: DefaultDateRenderer,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: DefaultDateRenderer,
		isStandalone: true,
		selector: "aur-default-date",
		host: { classAttribute: "aur-default-field" },
		usesInheritance: true,
		ngImport: i0,
		template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<input\n  #control\n  type=\"date\"\n  [id]=\"context().id\"\n  [value]=\"text()\"\n  [disabled]=\"context().disabled ?? false\"\n  [readOnly]=\"context().readOnly ?? false\"\n  (input)=\"update(control.value)\"\n/>\n"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: DefaultDateRenderer,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-date",
			host: { class: "aur-default-field" },
			template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<input\n  #control\n  type=\"date\"\n  [id]=\"context().id\"\n  [value]=\"text()\"\n  [disabled]=\"context().disabled ?? false\"\n  [readOnly]=\"context().readOnly ?? false\"\n  (input)=\"update(control.value)\"\n/>\n"
		}]
	}]
});
var DefaultTimeRenderer = class DefaultTimeRenderer extends FieldRendererBase {
	inputType = computed(() => (this.text().split(".")[1]?.length ?? 0) > 3 ? "text" : "time", ...ngDevMode ? [{ debugName: "inputType" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: DefaultTimeRenderer,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: DefaultTimeRenderer,
		isStandalone: true,
		selector: "aur-default-time",
		host: { classAttribute: "aur-default-field" },
		usesInheritance: true,
		ngImport: i0,
		template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<input\n  #control\n  [type]=\"inputType()\"\n  step=\"any\"\n  [id]=\"context().id\"\n  [value]=\"text()\"\n  [disabled]=\"context().disabled ?? false\"\n  [readOnly]=\"context().readOnly ?? false\"\n  (input)=\"update(control.value)\"\n/>\n"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: DefaultTimeRenderer,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-time",
			host: { class: "aur-default-field" },
			template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<input\n  #control\n  [type]=\"inputType()\"\n  step=\"any\"\n  [id]=\"context().id\"\n  [value]=\"text()\"\n  [disabled]=\"context().disabled ?? false\"\n  [readOnly]=\"context().readOnly ?? false\"\n  (input)=\"update(control.value)\"\n/>\n"
		}]
	}]
});
var DefaultEnumRenderer = class DefaultEnumRenderer extends FieldRendererBase {
	selectIndex(index) {
		if (index === 0) this.update(null);
		else {
			const value = this.context().choices?.[index - 1];
			if (value !== void 0) this.update(value);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: DefaultEnumRenderer,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.5",
		type: DefaultEnumRenderer,
		isStandalone: true,
		selector: "aur-default-enum",
		host: { classAttribute: "aur-default-field" },
		usesInheritance: true,
		ngImport: i0,
		template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<select #control [id]=\"context().id\" [disabled]=\"context().disabled || context().readOnly\"\n  (change)=\"selectIndex(control.selectedIndex)\">\n  <option [selected]=\"context().value === null\">Not set</option>\n  @for (choice of context().choices ?? []; track $index) {\n    <option [value]=\"choice\" [selected]=\"choice === text() && context().value !== null\">{{ choice === '' ? '(empty string)' : choice }}</option>\n  }\n</select>\n"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: DefaultEnumRenderer,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-enum",
			host: { class: "aur-default-field" },
			template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<select #control [id]=\"context().id\" [disabled]=\"context().disabled || context().readOnly\"\n  (change)=\"selectIndex(control.selectedIndex)\">\n  <option [selected]=\"context().value === null\">Not set</option>\n  @for (choice of context().choices ?? []; track $index) {\n    <option [value]=\"choice\" [selected]=\"choice === text() && context().value !== null\">{{ choice === '' ? '(empty string)' : choice }}</option>\n  }\n</select>\n"
		}]
	}]
});
var DefaultBinaryRenderer = class DefaultBinaryRenderer extends FieldRendererBase {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: DefaultBinaryRenderer,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: DefaultBinaryRenderer,
		isStandalone: true,
		selector: "aur-default-binary",
		host: { classAttribute: "aur-default-field" },
		usesInheritance: true,
		ngImport: i0,
		template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<output [id]=\"context().id\">{{ text() }}</output>\n"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: DefaultBinaryRenderer,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-default-binary",
			host: { class: "aur-default-field" },
			template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<output [id]=\"context().id\">{{ text() }}</output>\n"
		}]
	}]
});
const DEFAULT_ARTIFACTS = Object.freeze({
	[ThemeArtifact.Shell]: DefaultShell,
	[ThemeArtifact.Navigation]: DefaultNavigation,
	[ThemeArtifact.Panel]: DefaultPanel,
	[ThemeArtifact.FieldBoolean]: DefaultBooleanRenderer,
	[ThemeArtifact.FieldString]: DefaultStringRenderer,
	[ThemeArtifact.FieldText]: DefaultTextRenderer,
	[ThemeArtifact.FieldInt8]: DefaultNumberRenderer,
	[ThemeArtifact.FieldUint8]: DefaultNumberRenderer,
	[ThemeArtifact.FieldInt16]: DefaultNumberRenderer,
	[ThemeArtifact.FieldUint16]: DefaultNumberRenderer,
	[ThemeArtifact.FieldInt32]: DefaultNumberRenderer,
	[ThemeArtifact.FieldUint32]: DefaultNumberRenderer,
	[ThemeArtifact.FieldInt64]: DefaultNumberRenderer,
	[ThemeArtifact.FieldDecimal]: DefaultNumberRenderer,
	[ThemeArtifact.FieldUuid]: DefaultStringRenderer,
	[ThemeArtifact.FieldDate]: DefaultDateRenderer,
	[ThemeArtifact.FieldTime]: DefaultTimeRenderer,
	[ThemeArtifact.FieldDatetime]: DefaultStringRenderer,
	[ThemeArtifact.FieldEnum]: DefaultEnumRenderer,
	[ThemeArtifact.FieldBinary]: DefaultBinaryRenderer
});
const DEFAULT_THEME = Object.freeze({
	id: ThemeId.Default,
	cssClass: "theme-default",
	overrides: DEFAULT_ARTIFACTS
});
export { DEFAULT_ARTIFACTS, DEFAULT_THEME, DefaultBinaryRenderer, DefaultBooleanRenderer, DefaultDateRenderer, DefaultEnumRenderer, DefaultNavigation, DefaultNumberRenderer, DefaultPanel, DefaultShell, DefaultStringRenderer, DefaultTextRenderer, DefaultTimeRenderer };

//# sourceMappingURL=alxarafe-ui-theme-default.mjs.map