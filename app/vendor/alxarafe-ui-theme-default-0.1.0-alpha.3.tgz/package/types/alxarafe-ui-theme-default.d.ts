import { FieldRenderer, FieldRendererContext, FieldValue, ThemeDefinition, ThemeLinkActivationHandler, ThemeNavigationComponent, ThemeNavigationItem, ThemeNavigationSelection, ThemeShellComponent } from "@alxarafe/ui-runtime";
import * as i0 from "@angular/core";
export declare class DefaultNavigation implements ThemeNavigationComponent {
  readonly items: import("@angular/core").InputSignal<readonly ThemeNavigationItem[]>;
  readonly linkActivation: import("@angular/core").InputSignal<ThemeLinkActivationHandler | undefined>;
  readonly selected: import("@angular/core").OutputEmitterRef<ThemeNavigationSelection>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultNavigation, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DefaultNavigation, "aur-default-navigation", never, {
    "items": {
      "alias": "items";
      "required": false;
      "isSignal": true;
    };
    "linkActivation": {
      "alias": "linkActivation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selected";
  }, never, never, true, never>;
}
export declare class DefaultPanel {
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultPanel, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DefaultPanel, "aur-default-panel", never, {}, {}, never, ["*"], true, never>;
}
export declare class DefaultShell implements ThemeShellComponent {
  readonly navigation: import("@angular/core").InputSignal<readonly ThemeNavigationItem[]>;
  readonly linkActivation: import("@angular/core").InputSignal<ThemeLinkActivationHandler | undefined>;
  readonly navigationSelected: import("@angular/core").OutputEmitterRef<ThemeNavigationSelection>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultShell, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DefaultShell, "aur-default-shell", never, {
    "navigation": {
      "alias": "navigation";
      "required": false;
      "isSignal": true;
    };
    "linkActivation": {
      "alias": "linkActivation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "navigationSelected": "navigationSelected";
  }, never, ["[aur-theme-region=\"topbar-start\"]", "[aur-shell-heading]", "[aur-theme-region=\"topbar-actions\"]", "[aur-theme-region=\"navigation-before\"]", "[aur-theme-region=\"navigation-after\"]", "[aur-theme-region=\"content-before\"]", "[aur-theme-region=\"contextual-actions\"]", "[aur-shell-content]", "[aur-theme-region=\"content-after\"]", "[aur-theme-region=\"floating-actions\"]", "*", "[aur-shell-footer]", "[aur-theme-region=\"footer\"]"], true, never>;
}
declare abstract class FieldRendererBase implements FieldRenderer {
  readonly context: import("@angular/core").InputSignal<FieldRendererContext>;
  readonly valueChange: import("@angular/core").OutputEmitterRef<FieldValue>;
  readonly text: import("@angular/core").Signal<string>;
  update(value: FieldValue): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<FieldRendererBase, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<FieldRendererBase, never, never, {
    "context": {
      "alias": "context";
      "required": true;
      "isSignal": true;
    };
  }, {
    "valueChange": "valueChange";
  }, never, never, true, never>;
}
export declare class DefaultBooleanRenderer extends FieldRendererBase {
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultBooleanRenderer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DefaultBooleanRenderer, "aur-default-boolean", never, {}, {}, never, never, true, never>;
}
export declare class DefaultStringRenderer extends FieldRendererBase {
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultStringRenderer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DefaultStringRenderer, "aur-default-string", never, {}, {}, never, never, true, never>;
}
export declare class DefaultTextRenderer extends FieldRendererBase {
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultTextRenderer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DefaultTextRenderer, "aur-default-text", never, {}, {}, never, never, true, never>;
}
export declare class DefaultNumberRenderer extends FieldRendererBase {
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultNumberRenderer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DefaultNumberRenderer, "aur-default-number", never, {}, {}, never, never, true, never>;
}
export declare class DefaultDateRenderer extends FieldRendererBase {
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultDateRenderer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DefaultDateRenderer, "aur-default-date", never, {}, {}, never, never, true, never>;
}
export declare class DefaultTimeRenderer extends FieldRendererBase {
  readonly inputType: import("@angular/core").Signal<"text" | "time">;
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultTimeRenderer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DefaultTimeRenderer, "aur-default-time", never, {}, {}, never, never, true, never>;
}
export declare class DefaultEnumRenderer extends FieldRendererBase {
  selectIndex(index: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultEnumRenderer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DefaultEnumRenderer, "aur-default-enum", never, {}, {}, never, never, true, never>;
}
export declare class DefaultBinaryRenderer extends FieldRendererBase {
  static ɵfac: i0.ɵɵFactoryDeclaration<DefaultBinaryRenderer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DefaultBinaryRenderer, "aur-default-binary", never, {}, {}, never, never, true, never>;
}
export declare const DEFAULT_ARTIFACTS: Readonly<{
  shell: typeof DefaultShell;
  navigation: typeof DefaultNavigation;
  panel: typeof DefaultPanel;
  "field.BOOLEAN": typeof DefaultBooleanRenderer;
  "field.STRING": typeof DefaultStringRenderer;
  "field.TEXT": typeof DefaultTextRenderer;
  "field.INT8": typeof DefaultNumberRenderer;
  "field.UINT8": typeof DefaultNumberRenderer;
  "field.INT16": typeof DefaultNumberRenderer;
  "field.UINT16": typeof DefaultNumberRenderer;
  "field.INT32": typeof DefaultNumberRenderer;
  "field.UINT32": typeof DefaultNumberRenderer;
  "field.INT64": typeof DefaultNumberRenderer;
  "field.DECIMAL": typeof DefaultNumberRenderer;
  "field.UUID": typeof DefaultStringRenderer;
  "field.DATE": typeof DefaultDateRenderer;
  "field.TIME": typeof DefaultTimeRenderer;
  "field.DATETIME": typeof DefaultStringRenderer;
  "field.ENUM": typeof DefaultEnumRenderer;
  "field.BINARY": typeof DefaultBinaryRenderer;
}>;
export declare const DEFAULT_THEME: ThemeDefinition;
export {};