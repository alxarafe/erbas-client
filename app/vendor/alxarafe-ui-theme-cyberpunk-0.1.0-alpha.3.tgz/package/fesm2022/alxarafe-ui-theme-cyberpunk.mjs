import * as i0 from "@angular/core";
import { Component, input, output } from "@angular/core";
import { ThemeArtifact, ThemeNavigationOutlet, ThemePanelOutlet } from "@alxarafe/ui-runtime";
var CyberpunkPanel = class CyberpunkPanel {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: CyberpunkPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: CyberpunkPanel,
		isStandalone: true,
		selector: "aur-cyberpunk-panel",
		ngImport: i0,
		template: "<div class=\"aur-cyberpunk-panel\"><div class=\"aur-cyberpunk-panel-content\"><ng-content /></div></div>",
		isInline: true
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: CyberpunkPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-cyberpunk-panel",
			template: "<div class=\"aur-cyberpunk-panel\"><div class=\"aur-cyberpunk-panel-content\"><ng-content /></div></div>"
		}]
	}]
});
var CyberpunkShell = class CyberpunkShell {
	navigation = input([], ...ngDevMode ? [{ debugName: "navigation" }] : /* istanbul ignore next */ []);
	linkActivation = input(...ngDevMode ? [void 0, { debugName: "linkActivation" }] : /* istanbul ignore next */ []);
	navigationSelected = output();
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: CyberpunkShell,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: CyberpunkShell,
		isStandalone: true,
		selector: "aur-cyberpunk-shell",
		inputs: {
			navigation: {
				classPropertyName: "navigation",
				publicName: "navigation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			linkActivation: {
				classPropertyName: "linkActivation",
				publicName: "linkActivation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { navigationSelected: "navigationSelected" },
		ngImport: i0,
		template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<div class=\"aur-cyberpunk-shell\">\n  <header class=\"aur-cyberpunk-heading\">\n    <ng-content select='[aur-theme-region=\"topbar-start\"]' />\n    <ng-content select=\"[aur-shell-heading]\" />\n  </header>\n  <div class=\"aur-cyberpunk-workspace\">\n    <aside class=\"aur-cyberpunk-navigation\">\n      <ng-content select='[aur-theme-region=\"navigation-before\"]' />\n      <aur-theme-navigation [items]=\"navigation()\" [linkActivation]=\"linkActivation()\" (selected)=\"navigationSelected.emit($event)\" />\n      <ng-content select='[aur-theme-region=\"navigation-after\"]' />\n    </aside>\n    <main>\n      <ng-content select='[aur-theme-region=\"contextual-actions\"]' />\n      <ng-content select='[aur-theme-region=\"content-before\"]' />\n      <aur-theme-panel><ng-content select=\"[aur-shell-content]\" /></aur-theme-panel>\n      <ng-content select='[aur-theme-region=\"content-after\"]' />\n      <div><ng-content /></div>\n    </main>\n  </div>\n  <aside class=\"aur-cyberpunk-tools\" aria-label=\"Optional tools\">\n    <ng-content select='[aur-theme-region=\"topbar-actions\"]' />\n    <ng-content select='[aur-theme-region=\"floating-actions\"]' />\n  </aside>\n  <footer class=\"aur-cyberpunk-footer\">\n    <ng-content select=\"[aur-shell-footer]\" /><ng-content select='[aur-theme-region=\"footer\"]' />\n  </footer>\n</div>\n",
		dependencies: [{
			kind: "component",
			type: ThemeNavigationOutlet,
			selector: "aur-theme-navigation",
			inputs: ["items", "linkActivation"],
			outputs: ["selected"]
		}, {
			kind: "component",
			type: ThemePanelOutlet,
			selector: "aur-theme-panel"
		}]
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: CyberpunkShell,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-cyberpunk-shell",
			imports: [ThemeNavigationOutlet, ThemePanelOutlet],
			template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<div class=\"aur-cyberpunk-shell\">\n  <header class=\"aur-cyberpunk-heading\">\n    <ng-content select='[aur-theme-region=\"topbar-start\"]' />\n    <ng-content select=\"[aur-shell-heading]\" />\n  </header>\n  <div class=\"aur-cyberpunk-workspace\">\n    <aside class=\"aur-cyberpunk-navigation\">\n      <ng-content select='[aur-theme-region=\"navigation-before\"]' />\n      <aur-theme-navigation [items]=\"navigation()\" [linkActivation]=\"linkActivation()\" (selected)=\"navigationSelected.emit($event)\" />\n      <ng-content select='[aur-theme-region=\"navigation-after\"]' />\n    </aside>\n    <main>\n      <ng-content select='[aur-theme-region=\"contextual-actions\"]' />\n      <ng-content select='[aur-theme-region=\"content-before\"]' />\n      <aur-theme-panel><ng-content select=\"[aur-shell-content]\" /></aur-theme-panel>\n      <ng-content select='[aur-theme-region=\"content-after\"]' />\n      <div><ng-content /></div>\n    </main>\n  </div>\n  <aside class=\"aur-cyberpunk-tools\" aria-label=\"Optional tools\">\n    <ng-content select='[aur-theme-region=\"topbar-actions\"]' />\n    <ng-content select='[aur-theme-region=\"floating-actions\"]' />\n  </aside>\n  <footer class=\"aur-cyberpunk-footer\">\n    <ng-content select=\"[aur-shell-footer]\" /><ng-content select='[aur-theme-region=\"footer\"]' />\n  </footer>\n</div>\n"
		}]
	}],
	propDecorators: {
		navigation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "navigation",
				required: false
			}]
		}],
		linkActivation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "linkActivation",
				required: false
			}]
		}],
		navigationSelected: [{
			type: i0.Output,
			args: ["navigationSelected"]
		}]
	}
});
const CYBERPUNK_THEME = Object.freeze({
	id: "cyberpunk",
	cssClass: "theme-cyberpunk",
	overrides: Object.freeze({
		[ThemeArtifact.Shell]: CyberpunkShell,
		[ThemeArtifact.Panel]: CyberpunkPanel
	})
});
export { CYBERPUNK_THEME, CyberpunkPanel, CyberpunkShell };

//# sourceMappingURL=alxarafe-ui-theme-cyberpunk.mjs.map