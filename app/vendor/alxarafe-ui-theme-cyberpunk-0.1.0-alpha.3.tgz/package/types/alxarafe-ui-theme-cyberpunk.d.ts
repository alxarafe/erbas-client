import { ThemeDefinition, ThemeLinkActivationHandler, ThemeNavigationItem, ThemeNavigationSelection, ThemeShellComponent } from "@alxarafe/ui-runtime";
import * as i0 from "@angular/core";
export declare class CyberpunkPanel {
  static ɵfac: i0.ɵɵFactoryDeclaration<CyberpunkPanel, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CyberpunkPanel, "aur-cyberpunk-panel", never, {}, {}, never, ["*"], true, never>;
}
export declare class CyberpunkShell implements ThemeShellComponent {
  readonly navigation: import("@angular/core").InputSignal<readonly ThemeNavigationItem[]>;
  readonly linkActivation: import("@angular/core").InputSignal<ThemeLinkActivationHandler | undefined>;
  readonly navigationSelected: import("@angular/core").OutputEmitterRef<ThemeNavigationSelection>;
  static ɵfac: i0.ɵɵFactoryDeclaration<CyberpunkShell, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CyberpunkShell, "aur-cyberpunk-shell", never, {
    "navigation": {
      "alias": "navigation";
      "required": false;
      "isSignal": true;
    };
    "linkActivation": {
      "alias": "linkActivation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "navigationSelected": "navigationSelected";
  }, never, ["[aur-theme-region=\"topbar-start\"]", "[aur-shell-heading]", "[aur-theme-region=\"navigation-before\"]", "[aur-theme-region=\"navigation-after\"]", "[aur-theme-region=\"contextual-actions\"]", "[aur-theme-region=\"content-before\"]", "[aur-shell-content]", "[aur-theme-region=\"content-after\"]", "*", "[aur-theme-region=\"topbar-actions\"]", "[aur-theme-region=\"floating-actions\"]", "[aur-shell-footer]", "[aur-theme-region=\"footer\"]"], true, never>;
}
export declare const CYBERPUNK_THEME: ThemeDefinition;