import { ThemeDefinition } from "@alxarafe/ui-runtime";
export declare const VINTAGE_THEME: ThemeDefinition;