const VINTAGE_THEME = Object.freeze({
	id: "vintage",
	cssClass: "theme-vintage",
	overrides: Object.freeze({})
});
export { VINTAGE_THEME };

//# sourceMappingURL=alxarafe-ui-theme-vintage.mjs.map