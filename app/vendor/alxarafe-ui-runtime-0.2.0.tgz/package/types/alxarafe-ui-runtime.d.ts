import * as i0 from "@angular/core";
import { InputSignal, OutputEmitterRef, Provider, Type } from "@angular/core";
export type FieldValue = string | boolean | null;
export interface FieldRendererContext {
  readonly id: string;
  readonly label: string;
  readonly value: FieldValue;
  readonly disabled?: boolean;
  readonly readOnly?: boolean;
  readonly choices?: readonly string[];
}
export interface FieldRenderer {
  readonly context: InputSignal<FieldRendererContext>;
  readonly valueChange: OutputEmitterRef<FieldValue>;
}
export declare const FIELD_RENDERER_BINDINGS: {
  readonly context: "context";
  readonly valueChange: "valueChange";
};
export declare const ThemeArtifact: {
  readonly Shell: "shell";
  readonly Navigation: "navigation";
  readonly Panel: "panel";
  readonly FieldBoolean: "field.BOOLEAN";
  readonly FieldString: "field.STRING";
  readonly FieldText: "field.TEXT";
  readonly FieldInt8: "field.INT8";
  readonly FieldUint8: "field.UINT8";
  readonly FieldInt16: "field.INT16";
  readonly FieldUint16: "field.UINT16";
  readonly FieldInt32: "field.INT32";
  readonly FieldUint32: "field.UINT32";
  readonly FieldInt64: "field.INT64";
  readonly FieldDecimal: "field.DECIMAL";
  readonly FieldUuid: "field.UUID";
  readonly FieldDate: "field.DATE";
  readonly FieldTime: "field.TIME";
  readonly FieldDatetime: "field.DATETIME";
  readonly FieldEnum: "field.ENUM";
  readonly FieldBinary: "field.BINARY";
};
export type ThemeArtifact = (typeof ThemeArtifact)[keyof typeof ThemeArtifact];
export type FieldArtifact = Extract<ThemeArtifact, `field.${string}`>;
export type StructureArtifact = Exclude<ThemeArtifact, FieldArtifact>;
export type ThemeArtifacts = Readonly<Record<StructureArtifact, Type<unknown>> & Record<FieldArtifact, Type<FieldRenderer>>>;
export declare const THEME_ARTIFACTS: readonly ThemeArtifact[];
export declare const ThemeId: {
  readonly Default: "default";
};
export interface ThemeDefinition {
  readonly id: string;
  readonly cssClass: string;
  readonly overrides: Partial<ThemeArtifacts>;
}
export declare class ThemeRegistry {
  readonly all: readonly ThemeDefinition[];
  private readonly themes;
  constructor(definitions: readonly ThemeDefinition[]);
  find(id: string): ThemeDefinition | undefined;
  require(id: string): ThemeDefinition;
}
export declare class ThemeService {
  private readonly registry;
  private readonly selection;
  readonly current: import("@angular/core").Signal<ThemeDefinition>;
  activate(id: string): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ThemeResolver {
  private readonly registry;
  private readonly service;
  resolve<K extends ThemeArtifact>(artifact: K): ThemeArtifacts[K];
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeResolver, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare function provideThemeRuntime(themes: readonly ThemeDefinition[]): Provider[];
/** Technical bootstrap marker. No business or metadata API is defined yet. */
export declare const UI_RUNTIME_VERSION = "0.2.0";
//# sourceMappingURL=alxarafe-ui-runtime.d.ts.map