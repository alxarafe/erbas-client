import * as i0 from "@angular/core";
import { Injectable, inject, reflectComponentType, signal } from "@angular/core";
const ThemeArtifact = {
	Shell: "shell",
	Navigation: "navigation",
	Panel: "panel",
	FieldBoolean: "field.BOOLEAN",
	FieldString: "field.STRING",
	FieldText: "field.TEXT",
	FieldInt8: "field.INT8",
	FieldUint8: "field.UINT8",
	FieldInt16: "field.INT16",
	FieldUint16: "field.UINT16",
	FieldInt32: "field.INT32",
	FieldUint32: "field.UINT32",
	FieldInt64: "field.INT64",
	FieldDecimal: "field.DECIMAL",
	FieldUuid: "field.UUID",
	FieldDate: "field.DATE",
	FieldTime: "field.TIME",
	FieldDatetime: "field.DATETIME",
	FieldEnum: "field.ENUM",
	FieldBinary: "field.BINARY"
};
const THEME_ARTIFACTS = Object.freeze(Object.values(ThemeArtifact));
const ThemeId = { Default: "default" };
const FIELD_RENDERER_BINDINGS = {
	context: "context",
	valueChange: "valueChange"
};
const STYLE_ID = /^[a-z][a-z0-9-]*$/;
var ThemeRegistry = class {
	all;
	themes = /* @__PURE__ */ new Map();
	constructor(definitions) {
		for (const definition of definitions) {
			if (!STYLE_ID.test(definition.id) || !STYLE_ID.test(definition.cssClass) || this.themes.has(definition.id)) throw new Error("Invalid or duplicate theme identity");
			const overrides = { ...definition.overrides };
			for (const [key, component] of Object.entries(overrides)) {
				if (!THEME_ARTIFACTS.includes(key) || typeof component !== "function") throw new Error("Unknown or invalid theme artifact");
				const mirror = reflectComponentType(component);
				if (!mirror?.isStandalone) throw new Error("Theme artifacts must be compiled standalone components");
				if (key.startsWith("field.") && (!mirror.inputs.some((input) => input.templateName === FIELD_RENDERER_BINDINGS.context) || !mirror.outputs.some((output) => output.templateName === FIELD_RENDERER_BINDINGS.valueChange))) throw new Error("Invalid field renderer contract");
			}
			this.themes.set(definition.id, Object.freeze({
				...definition,
				overrides: Object.freeze(overrides)
			}));
		}
		const fallback = this.themes.get(ThemeId.Default);
		if (!fallback || THEME_ARTIFACTS.some((artifact) => !fallback.overrides[artifact])) throw new Error("Default theme must provide every artifact");
		this.all = Object.freeze([...this.themes.values()].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
	}
	find(id) {
		return this.themes.get(id);
	}
	require(id) {
		const theme = this.find(id);
		if (!theme) throw new Error("Unknown theme");
		return theme;
	}
};
var ThemeService = class ThemeService {
	registry = inject(ThemeRegistry);
	selection = signal(this.registry.require(ThemeId.Default), ...ngDevMode ? [{ debugName: "selection" }] : /* istanbul ignore next */ []);
	current = this.selection.asReadonly();
	activate(id) {
		const theme = this.registry.find(id);
		this.selection.set(theme ?? this.registry.require(ThemeId.Default));
		return theme !== void 0;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: ThemeService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: ThemeService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: ThemeService,
	decorators: [{ type: Injectable }]
});
var ThemeResolver = class ThemeResolver {
	registry = inject(ThemeRegistry);
	service = inject(ThemeService);
	resolve(artifact) {
		if (!THEME_ARTIFACTS.includes(artifact)) throw new Error("Unknown theme artifact");
		const component = this.service.current().overrides[artifact] ?? this.registry.require(ThemeId.Default).overrides[artifact];
		if (!component) throw new Error("Missing theme artifact");
		return component;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: ThemeResolver,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: ThemeResolver
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: ThemeResolver,
	decorators: [{ type: Injectable }]
});
function provideThemeRuntime(themes) {
	return [
		{
			provide: ThemeRegistry,
			useFactory: () => new ThemeRegistry(themes)
		},
		ThemeService,
		ThemeResolver
	];
}
const UI_RUNTIME_VERSION = "0.2.0";
export { FIELD_RENDERER_BINDINGS, THEME_ARTIFACTS, ThemeArtifact, ThemeId, ThemeRegistry, ThemeResolver, ThemeService, UI_RUNTIME_VERSION, provideThemeRuntime };

//# sourceMappingURL=alxarafe-ui-runtime.mjs.map