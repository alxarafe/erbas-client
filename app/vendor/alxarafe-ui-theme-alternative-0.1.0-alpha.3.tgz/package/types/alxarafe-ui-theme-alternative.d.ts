import { FieldRenderer, FieldRendererContext, FieldValue, ThemeDefinition } from "@alxarafe/ui-runtime";
import * as i0 from "@angular/core";
export declare const BOOLEAN_CHOICES: Readonly<{
  readonly yes: "yes";
  readonly no: "no";
  readonly unset: "";
}>;
export declare class AlternativeBooleanRenderer implements FieldRenderer {
  readonly context: import("@angular/core").InputSignal<FieldRendererContext>;
  readonly valueChange: import("@angular/core").OutputEmitterRef<FieldValue>;
  readonly choices: Readonly<{
    readonly yes: "yes";
    readonly no: "no";
    readonly unset: "";
  }>;
  select(value: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AlternativeBooleanRenderer, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AlternativeBooleanRenderer, "aur-alternative-boolean", never, {
    "context": {
      "alias": "context";
      "required": true;
      "isSignal": true;
    };
  }, {
    "valueChange": "valueChange";
  }, never, never, true, never>;
}
export declare const ALTERNATIVE_THEME: ThemeDefinition;