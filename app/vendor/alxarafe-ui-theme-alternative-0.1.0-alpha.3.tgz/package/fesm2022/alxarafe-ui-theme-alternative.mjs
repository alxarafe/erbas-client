import * as i0 from "@angular/core";
import { Component, input, output } from "@angular/core";
import { ThemeArtifact } from "@alxarafe/ui-runtime";
const BOOLEAN_CHOICES = Object.freeze({
	yes: "yes",
	no: "no",
	unset: ""
});
var AlternativeBooleanRenderer = class AlternativeBooleanRenderer {
	context = input.required(...ngDevMode ? [{ debugName: "context" }] : /* istanbul ignore next */ []);
	valueChange = output();
	choices = BOOLEAN_CHOICES;
	select(value) {
		if (this.context().disabled || this.context().readOnly) return;
		if (value === this.choices.yes) this.valueChange.emit(true);
		else if (value === this.choices.no) this.valueChange.emit(false);
		else if (value === this.choices.unset) this.valueChange.emit(null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: AlternativeBooleanRenderer,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.5",
		type: AlternativeBooleanRenderer,
		isStandalone: true,
		selector: "aur-alternative-boolean",
		inputs: { context: {
			classPropertyName: "context",
			publicName: "context",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		outputs: { valueChange: "valueChange" },
		host: { classAttribute: "aur-alternative-boolean" },
		ngImport: i0,
		template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<select\n  #control\n  [id]=\"context().id\"\n  [value]=\"\n    context().value === true ? choices.yes : context().value === false ? choices.no : choices.unset\n  \"\n  [disabled]=\"context().disabled || context().readOnly\"\n  (change)=\"select(control.value)\"\n>\n  <option [value]=\"choices.unset\" [selected]=\"context().value === null\">Not set</option>\n  <option [value]=\"choices.yes\" [selected]=\"context().value === true\">Yes</option>\n  <option [value]=\"choices.no\" [selected]=\"context().value === false\">No</option>\n</select>\n"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: AlternativeBooleanRenderer,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-alternative-boolean",
			host: { class: "aur-alternative-boolean" },
			template: "<!-- SPDX-License-Identifier: Apache-2.0; adapted from ERBAS; see NOTICE. -->\n<label [for]=\"context().id\">{{ context().label }}</label>\n<select\n  #control\n  [id]=\"context().id\"\n  [value]=\"\n    context().value === true ? choices.yes : context().value === false ? choices.no : choices.unset\n  \"\n  [disabled]=\"context().disabled || context().readOnly\"\n  (change)=\"select(control.value)\"\n>\n  <option [value]=\"choices.unset\" [selected]=\"context().value === null\">Not set</option>\n  <option [value]=\"choices.yes\" [selected]=\"context().value === true\">Yes</option>\n  <option [value]=\"choices.no\" [selected]=\"context().value === false\">No</option>\n</select>\n"
		}]
	}],
	propDecorators: {
		context: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "context",
				required: true
			}]
		}],
		valueChange: [{
			type: i0.Output,
			args: ["valueChange"]
		}]
	}
});
const ALTERNATIVE_THEME = Object.freeze({
	id: "alternative",
	cssClass: "theme-alternative",
	overrides: Object.freeze({ [ThemeArtifact.FieldBoolean]: AlternativeBooleanRenderer })
});
export { ALTERNATIVE_THEME, AlternativeBooleanRenderer, BOOLEAN_CHOICES };

//# sourceMappingURL=alxarafe-ui-theme-alternative.mjs.map