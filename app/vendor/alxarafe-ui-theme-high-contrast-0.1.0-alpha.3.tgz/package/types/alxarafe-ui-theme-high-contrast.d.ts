import { ThemeDefinition } from "@alxarafe/ui-runtime";
import * as i0 from "@angular/core";
export declare class HighContrastPanel {
  static ɵfac: i0.ɵɵFactoryDeclaration<HighContrastPanel, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<HighContrastPanel, "aur-high-contrast-panel", never, {}, {}, never, ["*"], true, never>;
}
export declare const HIGH_CONTRAST_THEME: ThemeDefinition;