import * as i0 from "@angular/core";
import { Component } from "@angular/core";
import { ThemeArtifact } from "@alxarafe/ui-runtime";
var HighContrastPanel = class HighContrastPanel {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: HighContrastPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.5",
		type: HighContrastPanel,
		isStandalone: true,
		selector: "aur-high-contrast-panel",
		ngImport: i0,
		template: "<div class=\"aur-high-contrast-panel\"><div class=\"aur-high-contrast-content\"><ng-content /></div></div>",
		isInline: true
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: HighContrastPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-high-contrast-panel",
			template: "<div class=\"aur-high-contrast-panel\"><div class=\"aur-high-contrast-content\"><ng-content /></div></div>"
		}]
	}]
});
const HIGH_CONTRAST_THEME = Object.freeze({
	id: "high-contrast",
	cssClass: "theme-high-contrast",
	overrides: Object.freeze({ [ThemeArtifact.Panel]: HighContrastPanel })
});
export { HIGH_CONTRAST_THEME, HighContrastPanel };

//# sourceMappingURL=alxarafe-ui-theme-high-contrast.mjs.map