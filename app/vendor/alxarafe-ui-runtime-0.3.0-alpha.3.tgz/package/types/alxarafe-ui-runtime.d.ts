import * as i0 from "@angular/core";
import { InputSignal, OutputEmitterRef, Provider, TemplateRef, Type } from "@angular/core";
export type FieldValue = string | boolean | null;
export interface FieldRendererContext {
  readonly id: string;
  readonly label: string;
  readonly value: FieldValue;
  readonly disabled?: boolean;
  readonly readOnly?: boolean;
  readonly choices?: readonly string[];
}
export interface FieldRenderer {
  readonly context: InputSignal<FieldRendererContext>;
  readonly valueChange: OutputEmitterRef<FieldValue>;
}
export declare const FIELD_RENDERER_BINDINGS: {
  readonly context: "context";
  readonly valueChange: "valueChange";
};
export declare const ThemeArtifact: {
  readonly Shell: "shell";
  readonly Navigation: "navigation";
  readonly Panel: "panel";
  readonly FieldBoolean: "field.BOOLEAN";
  readonly FieldString: "field.STRING";
  readonly FieldText: "field.TEXT";
  readonly FieldInt8: "field.INT8";
  readonly FieldUint8: "field.UINT8";
  readonly FieldInt16: "field.INT16";
  readonly FieldUint16: "field.UINT16";
  readonly FieldInt32: "field.INT32";
  readonly FieldUint32: "field.UINT32";
  readonly FieldInt64: "field.INT64";
  readonly FieldDecimal: "field.DECIMAL";
  readonly FieldUuid: "field.UUID";
  readonly FieldDate: "field.DATE";
  readonly FieldTime: "field.TIME";
  readonly FieldDatetime: "field.DATETIME";
  readonly FieldEnum: "field.ENUM";
  readonly FieldBinary: "field.BINARY";
};
export type ThemeArtifact = (typeof ThemeArtifact)[keyof typeof ThemeArtifact];
export type FieldArtifact = Extract<ThemeArtifact, `field.${string}`>;
export type StructureArtifact = Exclude<ThemeArtifact, FieldArtifact>;
export type ThemeArtifacts = Readonly<Record<StructureArtifact, Type<unknown>> & Record<FieldArtifact, Type<FieldRenderer>>>;
export declare const THEME_ARTIFACTS: readonly ThemeArtifact[];
export declare const ThemeId: {
  readonly Default: "default";
};
export interface ThemeDefinition {
  readonly id: string;
  readonly cssClass: string;
  readonly overrides: Partial<ThemeArtifacts>;
}
export declare class ThemeRegistry {
  readonly all: readonly ThemeDefinition[];
  private readonly themes;
  constructor(definitions: readonly ThemeDefinition[]);
  find(id: string): ThemeDefinition | undefined;
  require(id: string): ThemeDefinition;
}
export declare class ThemeService {
  private readonly registry;
  private readonly selection;
  readonly current: import("@angular/core").Signal<ThemeDefinition>;
  activate(id: string): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ThemeResolver {
  private readonly registry;
  private readonly service;
  resolve<K extends ThemeArtifact>(artifact: K): ThemeArtifacts[K];
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeResolver, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare function provideThemeRuntime(themes: readonly ThemeDefinition[]): Provider[];
/** Link intent only; cancellation is supported exclusively during the synchronous callback. */
export interface ThemeLinkActivation {
  readonly itemId: string;
  readonly href: string;
  readonly defaultPrevented: boolean;
  preventDefault(): void;
}
export type ThemeLinkActivationHandler = (activation: ThemeLinkActivation) => void;
/** Call once on an anchor's click. Modified clicks, other targets and downloads stay native. */
export declare function activateThemeLink(item: ThemeNavigationItem, event: MouseEvent, handler?: ThemeLinkActivationHandler): void;
/** A single application-owned navigation tree, not the proposed 1.0 menu model. */
export interface ThemeNavigationItem {
  readonly id: string;
  readonly label: string;
  readonly href?: string;
  readonly target?: string;
  readonly download?: string;
  readonly disabled?: boolean;
  readonly current?: boolean;
  readonly children?: readonly ThemeNavigationItem[];
}
/** Intent only: the application resolves the identity and performs the operation. */
export interface ThemeNavigationSelection {
  readonly itemId: string;
}
export declare const THEME_SHELL_BINDINGS: Readonly<{
  readonly navigation: "navigation";
  readonly navigationSelected: "navigationSelected";
  readonly linkActivation: "linkActivation";
}>;
export declare const THEME_NAVIGATION_BINDINGS: Readonly<{
  readonly items: "items";
  readonly selected: "selected";
  readonly linkActivation: "linkActivation";
}>;
export declare const THEME_SHELL_PROJECTION: Readonly<{
  readonly heading: "[aur-shell-heading]";
  readonly content: "[aur-shell-content]";
  readonly footer: "[aur-shell-footer]";
}>;
export declare const THEME_REGION_ATTRIBUTE = "aur-theme-region";
/** Templates remain owned by the application host; names are local presentation IDs. */
export type ThemeRegions = Readonly<Record<string, TemplateRef<unknown>>>;
export interface ThemeShellComponent {
  readonly linkActivation?: InputSignal<ThemeLinkActivationHandler | undefined>;
  readonly navigation: InputSignal<readonly ThemeNavigationItem[]>;
  readonly navigationSelected: OutputEmitterRef<ThemeNavigationSelection>;
}
export interface ThemeNavigationComponent {
  readonly linkActivation?: InputSignal<ThemeLinkActivationHandler | undefined>;
  readonly items: InputSignal<readonly ThemeNavigationItem[]>;
  readonly selected: OutputEmitterRef<ThemeNavigationSelection>;
}
/** Opt-in shell host. Application views outlive replaceable shell/panel instances. */
export declare class ThemeShellOutlet {
  readonly heading: import("@angular/core").InputSignal<TemplateRef<unknown> | undefined>;
  readonly content: import("@angular/core").InputSignal<TemplateRef<unknown>>;
  readonly footer: import("@angular/core").InputSignal<TemplateRef<unknown> | undefined>;
  readonly regions: import("@angular/core").InputSignal<Readonly<Record<string, TemplateRef<unknown>>>>;
  readonly navigation: import("@angular/core").InputSignal<readonly ThemeNavigationItem[]>;
  readonly linkActivation: import("@angular/core").InputSignal<ThemeLinkActivationHandler | undefined>;
  readonly navigationSelected: import("@angular/core").OutputEmitterRef<ThemeNavigationSelection>;
  protected readonly theme: ThemeService;
  private readonly resolver;
  private readonly renderer;
  private readonly injector;
  private readonly owned;
  private readonly target;
  private readonly views;
  private sourceOrder;
  private rendered?;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeShellOutlet, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ThemeShellOutlet, "aur-theme-shell", never, {
    "heading": {
      "alias": "heading";
      "required": false;
      "isSignal": true;
    };
    "content": {
      "alias": "content";
      "required": true;
      "isSignal": true;
    };
    "footer": {
      "alias": "footer";
      "required": false;
      "isSignal": true;
    };
    "regions": {
      "alias": "regions";
      "required": false;
      "isSignal": true;
    };
    "navigation": {
      "alias": "navigation";
      "required": false;
      "isSignal": true;
    };
    "linkActivation": {
      "alias": "linkActivation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "navigationSelected": "navigationSelected";
  }, never, never, true, never>;
}
/** Navigation presentation only: routing, authorization and intent execution stay outside. */
export declare class ThemeNavigationOutlet {
  readonly items: import("@angular/core").InputSignal<readonly ThemeNavigationItem[]>;
  readonly linkActivation: import("@angular/core").InputSignal<ThemeLinkActivationHandler | undefined>;
  readonly selected: import("@angular/core").OutputEmitterRef<ThemeNavigationSelection>;
  private readonly target;
  private readonly resolver;
  private rendered?;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeNavigationOutlet, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ThemeNavigationOutlet, "aur-theme-navigation", never, {
    "items": {
      "alias": "items";
      "required": false;
      "isSignal": true;
    };
    "linkActivation": {
      "alias": "linkActivation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selected";
  }, never, never, true, never>;
}
/** Projected views belong to this host, never to the resolved panel component. */
export declare class ThemePanelOutlet {
  private readonly projected;
  private readonly owned;
  private readonly target;
  private readonly resolver;
  private readonly injector;
  private view?;
  private rendered?;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemePanelOutlet, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ThemePanelOutlet, "aur-theme-panel", never, {}, {}, never, ["*"], true, never>;
}
/** Technical bootstrap marker. No business or metadata API is defined yet. */
export declare const UI_RUNTIME_VERSION = "0.3.0-alpha.3";
//# sourceMappingURL=alxarafe-ui-runtime.d.ts.map