import * as i0 from "@angular/core";
import { Component, Injectable, Injector, Renderer2, ViewContainerRef, afterNextRender, effect, inject, input, inputBinding, output, outputBinding, reflectComponentType, signal, viewChild } from "@angular/core";
const ThemeArtifact = {
	Shell: "shell",
	Navigation: "navigation",
	Panel: "panel",
	FieldBoolean: "field.BOOLEAN",
	FieldString: "field.STRING",
	FieldText: "field.TEXT",
	FieldInt8: "field.INT8",
	FieldUint8: "field.UINT8",
	FieldInt16: "field.INT16",
	FieldUint16: "field.UINT16",
	FieldInt32: "field.INT32",
	FieldUint32: "field.UINT32",
	FieldInt64: "field.INT64",
	FieldDecimal: "field.DECIMAL",
	FieldUuid: "field.UUID",
	FieldDate: "field.DATE",
	FieldTime: "field.TIME",
	FieldDatetime: "field.DATETIME",
	FieldEnum: "field.ENUM",
	FieldBinary: "field.BINARY"
};
const THEME_ARTIFACTS = Object.freeze(Object.values(ThemeArtifact));
const ThemeId = { Default: "default" };
const FIELD_RENDERER_BINDINGS = {
	context: "context",
	valueChange: "valueChange"
};
const STYLE_ID = /^[a-z][a-z0-9-]*$/;
var ThemeRegistry = class {
	all;
	themes = /* @__PURE__ */ new Map();
	constructor(definitions) {
		for (const definition of definitions) {
			if (!STYLE_ID.test(definition.id) || !STYLE_ID.test(definition.cssClass) || this.themes.has(definition.id)) throw new Error("Invalid or duplicate theme identity");
			const overrides = { ...definition.overrides };
			for (const [key, component] of Object.entries(overrides)) {
				if (!THEME_ARTIFACTS.includes(key) || typeof component !== "function") throw new Error("Unknown or invalid theme artifact");
				const mirror = reflectComponentType(component);
				if (!mirror?.isStandalone) throw new Error("Theme artifacts must be compiled standalone components");
				if (key.startsWith("field.") && (!mirror.inputs.some((input) => input.templateName === FIELD_RENDERER_BINDINGS.context) || !mirror.outputs.some((output) => output.templateName === FIELD_RENDERER_BINDINGS.valueChange))) throw new Error("Invalid field renderer contract");
			}
			this.themes.set(definition.id, Object.freeze({
				...definition,
				overrides: Object.freeze(overrides)
			}));
		}
		const fallback = this.themes.get(ThemeId.Default);
		if (!fallback || THEME_ARTIFACTS.some((artifact) => !fallback.overrides[artifact])) throw new Error("Default theme must provide every artifact");
		this.all = Object.freeze([...this.themes.values()].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
	}
	find(id) {
		return this.themes.get(id);
	}
	require(id) {
		const theme = this.find(id);
		if (!theme) throw new Error("Unknown theme");
		return theme;
	}
};
var ThemeService = class ThemeService {
	registry = inject(ThemeRegistry);
	selection = signal(this.registry.require(ThemeId.Default), ...ngDevMode ? [{ debugName: "selection" }] : /* istanbul ignore next */ []);
	current = this.selection.asReadonly();
	activate(id) {
		const theme = this.registry.find(id);
		this.selection.set(theme ?? this.registry.require(ThemeId.Default));
		return theme !== void 0;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: ThemeService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: ThemeService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: ThemeService,
	decorators: [{ type: Injectable }]
});
var ThemeResolver = class ThemeResolver {
	registry = inject(ThemeRegistry);
	service = inject(ThemeService);
	resolve(artifact) {
		if (!THEME_ARTIFACTS.includes(artifact)) throw new Error("Unknown theme artifact");
		const component = this.service.current().overrides[artifact] ?? this.registry.require(ThemeId.Default).overrides[artifact];
		if (!component) throw new Error("Missing theme artifact");
		return component;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: ThemeResolver,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: ThemeResolver
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: ThemeResolver,
	decorators: [{ type: Injectable }]
});
function provideThemeRuntime(themes) {
	return [
		{
			provide: ThemeRegistry,
			useFactory: () => new ThemeRegistry(themes)
		},
		ThemeService,
		ThemeResolver
	];
}
const THEME_SHELL_BINDINGS = Object.freeze({
	navigation: "navigation",
	navigationSelected: "navigationSelected",
	linkActivation: "linkActivation"
});
const THEME_NAVIGATION_BINDINGS = Object.freeze({
	items: "items",
	selected: "selected",
	linkActivation: "linkActivation"
});
const THEME_SHELL_PROJECTION = Object.freeze({
	heading: "[aur-shell-heading]",
	content: "[aur-shell-content]",
	footer: "[aur-shell-footer]"
});
const THEME_REGION_ATTRIBUTE = "aur-theme-region";
const pending = /* @__PURE__ */ new WeakMap();
function captureRetainedFocus(target, roots, injector) {
	const document = target.element.nativeElement.ownerDocument;
	const focused = document?.activeElement;
	if (!focused || !roots.some((root) => root.contains(focused))) return () => {};
	return () => {
		pending.get(focused)?.destroy();
		const ref = afterNextRender(() => {
			pending.delete(focused);
			const active = document?.activeElement;
			if (focused.isConnected && typeof focused.focus === "function" && (!active || active === document?.body)) focused.focus({ preventScroll: true });
		}, { injector });
		pending.set(focused, ref);
	};
}
const REGION_ID = /^[a-z][a-z0-9-]*$/;
const REGION_SELECTOR = /^\[aur-theme-region=(?:"([a-z][a-z0-9-]*)"|'([a-z][a-z0-9-]*)'|([a-z][a-z0-9-]*))\]$/;
function structureSelectors(component, artifact, requireLinkActivation = false) {
	const mirror = reflectComponentType(component);
	if (!mirror?.isStandalone) throw new Error("Structural ports require a compiled standalone component");
	const bindings = artifact === ThemeArtifact.Shell ? THEME_SHELL_BINDINGS : THEME_NAVIGATION_BINDINGS;
	if (artifact !== ThemeArtifact.Panel) {
		const [name, event] = Object.values(bindings);
		if (!mirror.inputs.some((input) => input.templateName === name) || !mirror.outputs.some((output) => output.templateName === event)) throw new Error(`Missing ${artifact} presentation bindings`);
	}
	if (requireLinkActivation && !mirror.inputs.some((input) => input.templateName === "linkActivation")) throw new Error(`Missing ${artifact} linkActivation capability`);
	const selectors = mirror.ngContentSelectors.map((selector) => {
		const region = REGION_SELECTOR.exec(selector)?.slice(1).find(Boolean);
		return region ? `[${THEME_REGION_ATTRIBUTE}="${region}"]` : selector;
	});
	const shellSelectors = Object.values(THEME_SHELL_PROJECTION);
	if (artifact === ThemeArtifact.Shell) {
		if (!selectors.includes(THEME_SHELL_PROJECTION.content) || !selectors.includes("*") || new Set(selectors).size !== selectors.length || selectors.some((selector) => selector !== "*" && !shellSelectors.includes(selector) && !REGION_SELECTOR.test(selector))) throw new Error("Shell requires content and catch-all projection with distinct supported selectors");
	} else if (artifact === ThemeArtifact.Panel && (selectors.length !== 1 || selectors[0] !== "*")) throw new Error("Panel requires exactly one catch-all projection");
	return selectors;
}
function linkActivationBindings(component, handler) {
	return reflectComponentType(component).inputs.some((input) => input.templateName === "linkActivation") ? [inputBinding("linkActivation", handler)] : [];
}
var ThemeShellOutlet = class ThemeShellOutlet {
	heading = input(...ngDevMode ? [void 0, { debugName: "heading" }] : /* istanbul ignore next */ []);
	content = input.required(...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	footer = input(...ngDevMode ? [void 0, { debugName: "footer" }] : /* istanbul ignore next */ []);
	regions = input({}, ...ngDevMode ? [{ debugName: "regions" }] : /* istanbul ignore next */ []);
	navigation = input([], ...ngDevMode ? [{ debugName: "navigation" }] : /* istanbul ignore next */ []);
	linkActivation = input(...ngDevMode ? [void 0, { debugName: "linkActivation" }] : /* istanbul ignore next */ []);
	navigationSelected = output();
	theme = inject(ThemeService);
	resolver = inject(ThemeResolver);
	renderer = inject(Renderer2);
	injector = inject(Injector);
	owned = viewChild("owned", {
		...ngDevMode ? { debugName: "owned" } : /* istanbul ignore next */ {},
		read: ViewContainerRef
	});
	target = viewChild("target", {
		...ngDevMode ? { debugName: "target" } : /* istanbul ignore next */ {},
		read: ViewContainerRef
	});
	views = /* @__PURE__ */ new Map();
	sourceOrder = [];
	rendered;
	constructor() {
		effect(() => {
			const owned = this.owned(), target = this.target();
			if (!owned || !target) return;
			const component = this.resolver.resolve(ThemeArtifact.Shell);
			const selectors = structureSelectors(component, ThemeArtifact.Shell, !!this.linkActivation());
			const sources = /* @__PURE__ */ new Map();
			for (const [name, template] of [
				["heading", this.heading()],
				["content", this.content()],
				["footer", this.footer()]
			]) if (template) sources.set(THEME_SHELL_PROJECTION[name], template);
			for (const [id, template] of Object.entries(this.regions())) {
				if (!REGION_ID.test(id)) throw new Error("Invalid theme region identity");
				sources.set(`[${THEME_REGION_ATTRIBUTE}="${id}"]`, template);
			}
			const keys = [...sources.keys()];
			if (!(keys.length !== this.sourceOrder.length || keys.some((key, index) => key !== this.sourceOrder[index]) || [...sources].some(([key, template]) => this.views.get(key)?.template !== template)) && component === this.rendered) return;
			const restoreFocus = captureRetainedFocus(target, [...this.views].filter(([key, entry]) => sources.get(key) === entry.template).map(([, entry]) => entry.wrapper), this.injector);
			target.clear();
			for (const [key, entry] of this.views) {
				if (sources.get(key) === entry.template) continue;
				const index = owned.indexOf(entry.view);
				if (index >= 0) owned.remove(index);
				this.views.delete(key);
			}
			for (const [key, template] of sources) {
				if (this.views.has(key)) continue;
				const view = owned.createEmbeddedView(template);
				const wrapper = this.renderer.createElement("div");
				const region = REGION_SELECTOR.exec(key);
				this.renderer.setAttribute(wrapper, region ? THEME_REGION_ATTRIBUTE : key.slice(1, -1), region?.[1] ?? region?.[2] ?? region?.[3] ?? "");
				for (const node of view.rootNodes) this.renderer.appendChild(wrapper, node);
				this.views.set(key, {
					template,
					view,
					wrapper
				});
			}
			const projection = selectors.map(() => []);
			for (const [key] of sources) {
				const index = selectors.indexOf(key);
				projection[index >= 0 ? index : selectors.indexOf("*")].push(this.views.get(key).wrapper);
			}
			target.createComponent(component, {
				projectableNodes: projection,
				bindings: [
					inputBinding(THEME_SHELL_BINDINGS.navigation, this.navigation),
					...linkActivationBindings(component, this.linkActivation),
					outputBinding(THEME_SHELL_BINDINGS.navigationSelected, (value) => this.navigationSelected.emit(value))
				]
			});
			this.rendered = component;
			this.sourceOrder = keys;
			restoreFocus();
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: ThemeShellOutlet,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.5",
		type: ThemeShellOutlet,
		isStandalone: true,
		selector: "aur-theme-shell",
		inputs: {
			heading: {
				classPropertyName: "heading",
				publicName: "heading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			content: {
				classPropertyName: "content",
				publicName: "content",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			footer: {
				classPropertyName: "footer",
				publicName: "footer",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			regions: {
				classPropertyName: "regions",
				publicName: "regions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			navigation: {
				classPropertyName: "navigation",
				publicName: "navigation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			linkActivation: {
				classPropertyName: "linkActivation",
				publicName: "linkActivation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { navigationSelected: "navigationSelected" },
		host: { properties: { "class": "theme.current().cssClass" } },
		viewQueries: [{
			propertyName: "owned",
			first: true,
			predicate: ["owned"],
			descendants: true,
			read: ViewContainerRef,
			isSignal: true
		}, {
			propertyName: "target",
			first: true,
			predicate: ["target"],
			descendants: true,
			read: ViewContainerRef,
			isSignal: true
		}],
		ngImport: i0,
		template: "<ng-container #owned /><ng-container #target />",
		isInline: true
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: ThemeShellOutlet,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-theme-shell",
			template: "<ng-container #owned /><ng-container #target />",
			host: { "[class]": "theme.current().cssClass" }
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		heading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "heading",
				required: false
			}]
		}],
		content: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "content",
				required: true
			}]
		}],
		footer: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "footer",
				required: false
			}]
		}],
		regions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "regions",
				required: false
			}]
		}],
		navigation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "navigation",
				required: false
			}]
		}],
		linkActivation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "linkActivation",
				required: false
			}]
		}],
		navigationSelected: [{
			type: i0.Output,
			args: ["navigationSelected"]
		}],
		owned: [{
			type: i0.ViewChild,
			args: ["owned", {
				read: ViewContainerRef,
				isSignal: true
			}]
		}],
		target: [{
			type: i0.ViewChild,
			args: ["target", {
				read: ViewContainerRef,
				isSignal: true
			}]
		}]
	}
});
var ThemeNavigationOutlet = class ThemeNavigationOutlet {
	items = input([], ...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	linkActivation = input(...ngDevMode ? [void 0, { debugName: "linkActivation" }] : /* istanbul ignore next */ []);
	selected = output();
	target = viewChild("target", {
		...ngDevMode ? { debugName: "target" } : /* istanbul ignore next */ {},
		read: ViewContainerRef
	});
	resolver = inject(ThemeResolver);
	rendered;
	constructor() {
		effect(() => {
			const target = this.target();
			if (!target) return;
			const component = this.resolver.resolve(ThemeArtifact.Navigation);
			structureSelectors(component, ThemeArtifact.Navigation, !!this.linkActivation());
			if (component === this.rendered) return;
			target.clear();
			target.createComponent(component, { bindings: [
				inputBinding(THEME_NAVIGATION_BINDINGS.items, this.items),
				...linkActivationBindings(component, this.linkActivation),
				outputBinding(THEME_NAVIGATION_BINDINGS.selected, (value) => this.selected.emit(value))
			] });
			this.rendered = component;
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: ThemeNavigationOutlet,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.5",
		type: ThemeNavigationOutlet,
		isStandalone: true,
		selector: "aur-theme-navigation",
		inputs: {
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			linkActivation: {
				classPropertyName: "linkActivation",
				publicName: "linkActivation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { selected: "selected" },
		viewQueries: [{
			propertyName: "target",
			first: true,
			predicate: ["target"],
			descendants: true,
			read: ViewContainerRef,
			isSignal: true
		}],
		ngImport: i0,
		template: "<ng-container #target />",
		isInline: true
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: ThemeNavigationOutlet,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-theme-navigation",
			template: "<ng-container #target />"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: false
			}]
		}],
		linkActivation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "linkActivation",
				required: false
			}]
		}],
		selected: [{
			type: i0.Output,
			args: ["selected"]
		}],
		target: [{
			type: i0.ViewChild,
			args: ["target", {
				read: ViewContainerRef,
				isSignal: true
			}]
		}]
	}
});
var ThemePanelOutlet = class ThemePanelOutlet {
	projected = viewChild("projected", ...ngDevMode ? [{ debugName: "projected" }] : /* istanbul ignore next */ []);
	owned = viewChild("owned", {
		...ngDevMode ? { debugName: "owned" } : /* istanbul ignore next */ {},
		read: ViewContainerRef
	});
	target = viewChild("target", {
		...ngDevMode ? { debugName: "target" } : /* istanbul ignore next */ {},
		read: ViewContainerRef
	});
	resolver = inject(ThemeResolver);
	injector = inject(Injector);
	view;
	rendered;
	constructor() {
		effect(() => {
			const source = this.projected(), owned = this.owned(), target = this.target();
			if (!source || !owned || !target) return;
			const component = this.resolver.resolve(ThemeArtifact.Panel);
			if (component === this.rendered) return;
			structureSelectors(component, ThemeArtifact.Panel);
			this.view ??= owned.createEmbeddedView(source);
			const restoreFocus = captureRetainedFocus(target, this.view.rootNodes, this.injector);
			target.clear();
			target.createComponent(component, { projectableNodes: [this.view.rootNodes] });
			this.rendered = component;
			restoreFocus();
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.5",
		ngImport: i0,
		type: ThemePanelOutlet,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.5",
		type: ThemePanelOutlet,
		isStandalone: true,
		selector: "aur-theme-panel",
		viewQueries: [
			{
				propertyName: "projected",
				first: true,
				predicate: ["projected"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "owned",
				first: true,
				predicate: ["owned"],
				descendants: true,
				read: ViewContainerRef,
				isSignal: true
			},
			{
				propertyName: "target",
				first: true,
				predicate: ["target"],
				descendants: true,
				read: ViewContainerRef,
				isSignal: true
			}
		],
		ngImport: i0,
		template: "<ng-template #projected><ng-content /></ng-template><ng-container #owned /><ng-container #target />",
		isInline: true
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: ThemePanelOutlet,
	decorators: [{
		type: Component,
		args: [{
			selector: "aur-theme-panel",
			template: "<ng-template #projected><ng-content /></ng-template><ng-container #owned /><ng-container #target />"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		projected: [{
			type: i0.ViewChild,
			args: ["projected", { isSignal: true }]
		}],
		owned: [{
			type: i0.ViewChild,
			args: ["owned", {
				read: ViewContainerRef,
				isSignal: true
			}]
		}],
		target: [{
			type: i0.ViewChild,
			args: ["target", {
				read: ViewContainerRef,
				isSignal: true
			}]
		}]
	}
});
function activateThemeLink(item, event, handler) {
	const anchor = event.currentTarget;
	const target = anchor?.getAttribute("target") || anchor?.ownerDocument.querySelector("base[target]")?.getAttribute("target");
	if (!handler || item.disabled || !item.href || !event.cancelable || event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey || anchor?.hasAttribute("download") || target && target.toLowerCase() !== "_self") return;
	let dispatching = true;
	const activation = Object.freeze({
		itemId: item.id,
		href: item.href,
		get defaultPrevented() {
			return event.defaultPrevented;
		},
		preventDefault() {
			if (dispatching) event.preventDefault();
		}
	});
	try {
		handler(activation);
	} finally {
		dispatching = false;
	}
}
const UI_RUNTIME_VERSION = "0.3.0-alpha.3";
export { FIELD_RENDERER_BINDINGS, THEME_ARTIFACTS, THEME_NAVIGATION_BINDINGS, THEME_REGION_ATTRIBUTE, THEME_SHELL_BINDINGS, THEME_SHELL_PROJECTION, ThemeArtifact, ThemeId, ThemeNavigationOutlet, ThemePanelOutlet, ThemeRegistry, ThemeResolver, ThemeService, ThemeShellOutlet, UI_RUNTIME_VERSION, activateThemeLink, provideThemeRuntime };

//# sourceMappingURL=alxarafe-ui-runtime.mjs.map